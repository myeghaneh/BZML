# coding: utf8
import os
from .util import log, ENV_VARS

if os.environ.get(ENV_VARS.FASTAPI):
    log("APP: Using FastAPI endpoints")
    from ._api.fastapi_app import *
else:
    log("APP: Using Hug endpoints (deprecated)")
    from ._api.hug_app import *

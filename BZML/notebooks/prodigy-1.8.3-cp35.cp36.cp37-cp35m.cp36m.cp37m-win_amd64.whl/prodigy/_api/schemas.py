from typing import List, Optional

from pydantic import BaseModel, Schema

#
# Schemas
#


class SessionID(BaseModel):
    session_id: str
    aliases: List[str] = []


class JWTPayload(BaseModel):
    """JSON Web Token payload"""

    exp: int = Schema(
        ..., description="The expiration date of the token in UTC milliseconds"
    )
    aud: str = Schema(..., description="The audience that the token is intended for")
    iss: str = Schema(..., description="The issuer of the auth token.")


class APIVersionResponse(BaseModel):
    name: str
    description: str
    author: str
    author_email: str
    url: str
    version: str
    license: str


class APIProjectResponse(BaseModel):
    pass


class APISessionQuestionsRequest(BaseModel):
    session_id: str


class APIQuestionsResponse(BaseModel):
    tasks: List
    total: int
    progress: Optional[float]
    session_id: str


class APIAnswersRequest(BaseModel):
    answers: List
    session_id: str = None


class APIAnswersResponse(BaseModel):
    progress: Optional[float]


class APISessionAliasesRequest(BaseModel):
    session_id: str
    aliases: List

# coding: utf8
from __future__ import unicode_literals

import os

import falcon
import hug
import jwt
import srsly
from hug.authentication import authenticator
from hug.middleware import CORSMiddleware

from .. import about
from ..util import ENV_VARS, get_valid_sessions, log, prints
from .shared import (
    get_basic_auth_config,
    get_jwt_config,
    set_controller,
    get_controller,
    get_config,
    static_files_folder,
)

HUG_API = hug.API(__name__)


def assert_known_session(session_id):
    """Raise a Hug error if the given session_id doesn't match the user specified
    list. If the user hasn't specified a list of sessions, any are allowed.
    """
    sessions = get_valid_sessions()
    if sessions is None:
        return
    if session_id is None:
        raise falcon.HTTPBadRequest(
            title="unauthorized",
            description="a registered session id is required for this task",
        )
    if session_id not in sessions:
        raise falcon.HTTPUnauthorized(
            title="unauthorized",
            description="session is not present in recipe specified list",
        )


@authenticator
def static_guard_basic_auth(request, response, verify_user, **kwargs):
    """Hug authenticator for conditionally requiring HTTP basic auth to access the
    prodigy web application. See `get_basic_auth_config` for more information."""

    def verify_basic_auth_user(user_name, user_password):
        check_user, check_pass = get_basic_auth_config()
        if user_name == check_user and user_password == check_pass:
            return user_name
        return False

    if get_basic_auth_config() == (None, None):
        return "basic_auth_disabled_by_configuration"

    basic_auth_fn = hug.authentication.basic(verify_basic_auth_user)
    return basic_auth_fn(request, response, **kwargs)


@static_guard_basic_auth
def conditional_basic_auth(username):
    """Passthrough once the basic auth check has succeeded"""
    return username


def get_cors_middleware():
    global HUG_API
    cors_origin = os.environ.get(ENV_VARS.CORS_ORIGIN, None)
    # If JWTs are configured, specify allow credentials and the cors origin
    if get_jwt_config() is not (None, None) and cors_origin is not None:
        allowed_origins = cors_origin
        if type(allowed_origins) is str:
            allowed_origins = allowed_origins.split(",")
        log("CORS: initializing JWT endpoints with origins: {}".format(allowed_origins))
        return CORSMiddleware(
            HUG_API, allow_credentials="true", allow_origins=allowed_origins
        )
    log('CORS: initialize wildcard "*" CORS origins')
    return CORSMiddleware(HUG_API)


@authenticator
def api_jwt(request, response, verify_user, **kwargs):
    token = request.get_header("Authorization")
    bearer_prefix = "Bearer "
    if token and bearer_prefix in token:
        token = (
            token[len(bearer_prefix) :] if token.startswith(bearer_prefix) else token
        )
        verified_token = verify_user(token)
        if verified_token:
            return verified_token
        else:
            log("JWT: caller token did not validate", token)
            return False
    if get_jwt_config() == (None, None):
        return "token_auth_disabled_by_configuration"
    log("JWT: no token present in request", token)
    return None


@api_jwt
def conditional_api_token(token):
    """Verify the claims and signature of a given token"""
    # JWT shared secret configuration
    token_secret, token_audience = get_jwt_config()
    token_algorithm = "HS256"
    if token_secret is None and token_audience is None:
        return {}
    try:
        return jwt.decode(
            token, token_secret, algorithms=[token_algorithm], audience=token_audience
        )
    except BaseException as error:
        raise falcon.HTTPUnauthorized(str(error), "The provided token is invalid")


def server(controller, config):
    """Serve the Prodigy REST API.

    controller (prodigy.core.Controller): The initialized controller.
    config (dict): Configuration settings, e.g. via a prodigy.json or recipe.
    """
    global HUG_API
    set_controller(controller, config)

    from waitress.server import create_server

    if config.get("cors", True) is not False:
        HUG_API.http.add_middleware(get_cors_middleware())
    static_files_auth = get_basic_auth_config()
    if static_files_auth != (None, None):
        user = static_files_auth[0]
        log("HTTP: adding basic auth to static files with username: {}".format(user))
    port = os.getenv(ENV_VARS.PORT, config.get("port", 8080))
    host = os.getenv(ENV_VARS.HOST, config.get("host", "localhost"))
    server = create_server(
        __hug_wsgi__,  # noqa: F821
        port=port,
        host=host,
        channel_timeout=300,
        expose_tracebacks=True,
        threads=1,
    )
    prints(
        "Starting the web server at http://{}:{} ...".format(host, port),
        "Open the app in your browser and start annotating!",
    )
    server.run()
    controller.save()


@hug.response_middleware()
def process_data(request, response, resource):
    # required to make sure browsers never cache the response (e.g. IE 11)
    response.set_header("Cache-control", "no-cache")


@hug.static("/", requires=conditional_basic_auth)
def serve_static():
    return (static_files_folder(),)


@hug.get("/version", requires=conditional_api_token)
def version():
    return dict(
        name="prodigy",
        description=about.__summary__,
        author=about.__author__,
        author_email=about.__email__,
        url=about.__uri__,
        version=about.__version__,
        license=about.__license__,
    )


@hug.get("/project", requires=conditional_api_token)
@hug.get("/project/{session_id}", requires=conditional_api_token)
def get_project(session_id: hug.types.text = None):
    """Get the meta data and configuration of the current project.

    RETURNS (dict): The configuration parameters and settings.
    """
    log("GET: /project", get_config())
    assert_known_session(session_id)
    config = {}
    for key, value in get_config().items():
        if srsly.is_json_serializable(value):
            config[key] = value
    return config


@hug.get("/get_questions", requires=conditional_api_token)
def get_questions():
    """Get the next batch of tasks to annotate.
    RETURNS (dict): {'tasks': list, 'total': int, 'progress': float}
    """
    log("GET: /get_questions")
    controller = get_controller()
    if controller.db and hasattr(controller.db, "reconnect"):
        controller.db.reconnect()
    tasks = controller.get_questions()
    response = {
        "tasks": tasks,
        "total": controller.total_annotated,
        "progress": controller.progress,
    }
    log("RESPONSE: /get_questions ({} examples)".format(len(tasks)), response)
    if controller.db and hasattr(controller.db, "close"):
        controller.db.close()
    return response


@hug.post("/get_session_questions", requires=conditional_api_token)
def get_session_questions(session_id: hug.types.text):
    """Get the next batch of tasks to annotate for a given session_id

    RETURNS (dict): {'tasks': list, 'total': int, 'progress': float, 'session_id': str}
    """
    log("POST: /get_session_questions")
    controller = get_controller()
    if controller.db and hasattr(controller.db, "reconnect"):
        controller.db.reconnect()
    tasks = controller.get_questions(session_id=session_id)
    out_session = session_id if session_id is not None else controller.session_id
    response = {
        "tasks": tasks,
        "total": controller.total_annotated,
        "progress": controller.progress,
        "session_id": out_session,
    }
    log("RESPONSE: /get_session_questions ({} examples)".format(len(tasks)), response)
    if controller.db and hasattr(controller.db, "close"):
        controller.db.close()
    return response


@hug.post("/set_session_aliases", requires=conditional_api_token)
def set_session_aliases(session_id: hug.types.text, aliases=[]):
    """Set the list of past session_ids to associate with a current session_id. This
    is useful for recipes that require overlap but want to exclude questions an annotator
    has seen before in a previous session for the same task.

    RETURNS (dict): {'session_id': str}
    """
    log("POST: /set_session_aliases")
    controller = get_controller()
    controller.set_session_aliases(session_id, aliases)
    response = {"session_id": session_id}
    return response


@hug.post("/end_session", requires=conditional_api_token)
def end_session(session_id: hug.types.text):
    """Tell the prodigy controller that it can release the resources held for the
    given session_id.
    """
    log("POST: /end_session")
    controller = get_controller()
    response = controller.end_session(session_id)
    log("RESPONSE: /end_session ({})".format(response), response)
    return response


@hug.post("/give_answers", requires=conditional_api_token)
def give_answers(answers=[], session_id=None):
    """Receive annotated answers, e.g. from the web app.

    answers (list): A list of task dictionaries with an added `"answer"` key.
    session_id (str): The session id string that points to a dataset
    RETURNS (dict): {'progress': float}
    """
    id_info = ", session ID '{}'".format(session_id) if session_id else ""
    log("POST: /give_answers (received {}{})".format(len(answers), id_info), answers)
    controller = get_controller()
    if controller.db and hasattr(controller.db, "reconnect"):
        controller.db.reconnect()
    controller.receive_answers(answers, session_id=session_id)
    response = {"progress": controller.progress}
    log("RESPONSE: /give_answers", response)
    if controller.db and hasattr(controller.db, "close"):
        controller.db.close()
    return response


if __name__ == "__main__":
    import plac

    plac.call(server)

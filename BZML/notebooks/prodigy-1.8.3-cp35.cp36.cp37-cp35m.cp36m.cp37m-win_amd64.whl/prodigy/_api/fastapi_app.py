# coding: utf8
import os
import jwt
import datetime
from pathlib import Path
import uvicorn
from starlette.staticfiles import StaticFiles
from starlette.responses import HTMLResponse, PlainTextResponse
from starlette.requests import Request
from fastapi import Depends, FastAPI, HTTPException, APIRouter
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import srsly
from ..util import prints, log, get_valid_sessions, ENV_VARS
from .hug_app import get_jwt_config
from .jwt import JWTBearer
from .. import about
from starlette.status import HTTP_403_FORBIDDEN, HTTP_401_UNAUTHORIZED
from .schemas import (
    APIAnswersRequest,
    APIVersionResponse,
    APIQuestionsResponse,
    APISessionQuestionsRequest,
    SessionID,
    APIAnswersResponse,
)
from .shared import (
    get_basic_auth_config,
    set_controller,
    get_config,
    get_controller,
    JWT_FALLBACK_EXPIRE,
    JWT_COOKIE_NAME,
)

API_DOCSTRING = "REST endpoints used for interacting with Prodigy tasks"

#
# Application Configuration
#

app = FastAPI(title="Prodigy", description=API_DOCSTRING, version=about.__version__)


def read_files(path):
    """Read the static content once, to avoid reading on each request."""
    with (path / "index.html").open("r", encoding="utf8") as file_:
        index = file_.read()
    with (path / "bundle.js").open("r", encoding="utf8") as file_:
        javascript = file_.read()
    with (path / "favicon.ico").open("rb") as file_:
        favicon = file_.read()
    return index, javascript, favicon


static_dir = Path(__file__).parent.parent / "static"
INDEX_HTML, JAVASCRIPT, FAVICON = read_files(static_dir)

app.mount("/fonts", StaticFiles(directory=str(static_dir / "fonts")))

#
# Auth
#


def assert_known_session(session_id):
    """Raise a FastAPI error if the given session_id doesn't match the user specified
    list. If the user hasn't specified a list of sessions, any are allowed.
    """
    sessions = get_valid_sessions()
    if sessions is None:
        return
    if session_id is None:
        raise HTTPException(
            status_code=HTTP_403_FORBIDDEN,
            detail="a registered session id is required for this task",
        )
    if session_id not in sessions:
        raise HTTPException(
            status_code=HTTP_403_FORBIDDEN,
            detail="session is not present in recipe specified list",
        )


BASIC_AUTH_CONTROLLER = HTTPBasic()


async def get_basic_auth(request: Request):
    global BASIC_AUTH_CONTROLLER

    # Check for disabled auth configuration before using the auth controller.
    # NOTE: this is so that when auth is disabled the client doesn't get sent
    #       an authorization prompt, which happens when the auth controller is
    #       called by the DepInjector. I tried auto_error=False but then I needed
    #       to call it again later to get the auth challenge headers needed in
    #       a failure response. This ends up being the cleanest way I've found.
    basic_username, basic_password = get_basic_auth_config()
    if basic_password is None and basic_username is None:
        return None
    if basic_password is None or basic_username is None:
        raise ValueError(
            "Invalid configuration."
            "You cannot specify one HTTP basic auth environment variable without the other"
        )

    # Invoke HTTP Basic auth challenge/handler
    credentials: HTTPBasicCredentials = await BASIC_AUTH_CONTROLLER(request)
    if credentials.username != basic_username or credentials.password != basic_password:
        raise HTTPException(
            status_code=HTTP_401_UNAUTHORIZED, detail="Incorrect email or password"
        )
    else:
        return credentials


JWTController = JWTBearer(*get_jwt_config(default_config=True))

static = APIRouter()
routes = APIRouter()


#
# API
#


def serve_main():
    """Serve the main React application and set a httponly cookie
    that enables the client page to make calls to the server."""
    response = HTMLResponse(INDEX_HTML)
    expire = os.getenv(ENV_VARS.JWT_EXPIRE_SECONDS, JWT_FALLBACK_EXPIRE)
    secret, audience = get_jwt_config(default_config=True)
    issuer = os.getenv(ENV_VARS.HOST, audience)
    token = encode_token(secret, audience, issuer, expire)
    response.set_cookie(
        JWT_COOKIE_NAME,
        value=token.decode("utf-8"),
        domain=issuer,
        httponly=True,
        max_age=expire,
        expires=expire,
    )
    return response


@static.get("/")
def static_root():
    return serve_main()


def encode_token(secret, audience, issuer, expire_seconds):
    """Encode a JWT for accessing the prodigy API routes"""
    payload = {
        "exp": datetime.datetime.utcnow() + datetime.timedelta(seconds=expire_seconds),
        "aud": audience,
        "iss": issuer,
    }
    return jwt.encode(payload, secret)


@static.get("/index.html")
def static_index():
    return serve_main()


@static.get("/bundle.js")
def static_bundle():
    return PlainTextResponse(JAVASCRIPT)


@static.get("/favicon.ico")
def static_favicon():
    return PlainTextResponse(FAVICON)


@routes.get("/version", response_model=APIVersionResponse)
def version():
    return dict(
        name="prodigy",
        description=about.__summary__,
        author=about.__author__,
        author_email=about.__email__,
        url=about.__uri__,
        version=about.__version__,
        license=about.__license__,
    )


@routes.get("/project")
def get_project():
    log("GET: /project", get_config())
    assert_known_session(None)
    config = {}
    for key, value in get_config().items():
        if srsly.is_json_serializable(value):
            config[key] = value
    return config


@routes.get("/project/{session_id}")
def get_session_project(session_id: str):
    assert_known_session(session_id)
    config = {}
    for key, value in get_config().items():
        if srsly.is_json_serializable(value):
            config[key] = value
    return config


def _shared_get_questions(session_id: str):
    """Because of route decorators we can't call through
    to another route by invoking the fn directly. Move the
    shared logic here into a plain fn"""
    controller = get_controller()
    if controller.db and hasattr(controller.db, "reconnect"):
        controller.db.reconnect()
    tasks = controller.get_questions(session_id=session_id)
    out_session = session_id if session_id is not None else controller.session_id
    response = {
        "tasks": tasks,
        "total": controller.total_annotated,
        "progress": controller.progress,
        "session_id": out_session,
    }
    log("RESPONSE: /get_session_questions ({} examples)".format(len(tasks)), response)
    if controller.db and hasattr(controller.db, "close"):
        controller.db.close()
    return response


@routes.get("/get_questions", response_model=APIQuestionsResponse)
def get_questions():
    """Get the next batch of tasks to annotate.
    RETURNS (dict): {'tasks': list, 'total': int, 'progress': float}
    """
    return _shared_get_questions(None)


@routes.post("/get_session_questions", response_model=APIQuestionsResponse)
def get_session_questions(req: APISessionQuestionsRequest):
    """Get the next batch of tasks to annotate for a given session_id

    RETURNS (dict): {'tasks': list, 'total': int, 'progress': float, 'session_id': str}
    """
    log("POST: /get_session_questions")
    return _shared_get_questions(req.session_id)


@routes.post("/set_session_aliases", response_model=SessionID)
def set_session_aliases(req: SessionID):
    """Set the list of past session_ids to associate with a current session_id. This
    is useful for recipes that require overlap but want to exclude questions an annotator
    has seen before in a previous session for the same task.

    RETURNS (dict): {'session_id': str}
    """
    log("POST: /set_session_aliases")
    controller = get_controller()
    controller.set_session_aliases(req.session_id, req.aliases)
    return {"session_id": req.session_id}


@routes.post("/end_session")
def end_session(req: SessionID):
    """Tell the prodigy controller that it can release the resources held for the
    given session_id.
    """
    log("POST: /end_session")
    controller = get_controller()
    response = controller.end_session(req.session_id)
    log("RESPONSE: /end_session ({})".format(response), response)
    return response


@routes.post("/give_answers", response_model=APIAnswersResponse)
def give_answers(req: APIAnswersRequest):
    """Receive annotated answers, e.g. from the web app.

    answers (list): A list of task dictionaries with an added `"answer"` key.
    session_id (str): The session id string that points to a dataset
    RETURNS (dict): {'progress': float}
    """
    session_id = req.session_id
    answers = req.answers
    id_info = ", session ID '{}'".format(session_id) if session_id else ""
    log("POST: /give_answers (received {}{})".format(len(answers), id_info), answers)
    controller = get_controller()
    if controller.db and hasattr(controller.db, "reconnect"):
        controller.db.reconnect()
    controller.receive_answers(answers, session_id=session_id)
    response = {"progress": controller.progress}
    log("RESPONSE: /give_answers", response)
    if controller.db and hasattr(controller.db, "close"):
        controller.db.close()
    return response


app.include_router(static, tags=["static"], dependencies=[Depends(get_basic_auth)])
app.include_router(routes, tags=["api"], dependencies=[Depends(JWTController)])


def server(controller, config):
    """Serve the Prodigy REST API.

    controller (prodigy.core.Controller): The initialized controller.
    config (dict): Configuration settings, e.g. via a prodigy.json or recipe.
    """
    set_controller(controller, config)

    port = os.getenv(ENV_VARS.PORT, config.get("port", 8080))
    host = os.getenv(ENV_VARS.HOST, config.get("host", "localhost"))

    prints(
        "Starting the web server at http://{}:{} ...".format(host, port),
        "Open the app in your browser and start annotating!",
    )
    uvicorn.run(app, host=host, port=int(port))
    controller.save()

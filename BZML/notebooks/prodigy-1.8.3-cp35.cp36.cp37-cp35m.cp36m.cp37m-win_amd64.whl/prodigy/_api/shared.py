import os
import uuid
from pathlib import Path

from .. import about
from ..util import ENV_VARS, prints

CONFIG = {}
CONTROLLER = None
# The name used for prodigy JWT cookies
JWT_COOKIE_NAME = "_prodigy_"


def static_files_folder():
    """Return the static files root path used by the prodigy application"""
    return str(Path(__file__).parent.parent / "static")


def set_controller(controller, config):
    """Prepare a controller/config for hosting the prodigy application and API endpoints"""
    global CONTROLLER, CONFIG
    config["view_id"] = controller.view_id
    config["batch_size"] = controller.batch_size
    config["version"] = about.__version__
    instructions = config.get("instructions")
    if instructions:
        help_path = Path(instructions)
        if not help_path.is_file():
            prints("Can't read instructions", help_path, error=True, exits=1)
        with help_path.open("r", encoding="utf8") as f:
            config["instructions"] = f.read()
    for setting in ["db_settings", "api_keys"]:
        if setting in config:
            config.pop(setting)
    CONFIG = config
    CONTROLLER = controller


def get_controller():
    global CONTROLLER
    return CONTROLLER


def get_config():
    global CONFIG
    return CONFIG


# Generate a uuid secret if the user hasn't specified one.
JWT_FALLBACK_SECRET = uuid.uuid4().hex
# Default JWT expiration time in seconds
JWT_FALLBACK_EXPIRE = 60 * 60 * 24  # 24 hours


def get_jwt_config(default_config=False):
    """Get the JSONWebToken auth configuration from the environment.

    PRODIGY_JWT_SECRET is a shared secret that is used for signing tokens
    and verifying them. Use this secret when generating tokens that will be
    used to authenticate calls to prodigy.

    PRODIGY_JWT_AUDIENCE is set to the web address that prodigy will be running
    at, for example http://localhost:8080. The same value must be used when signing
    the tokens and when verifying them.
    """
    global JWT_FALLBACK_SECRET
    default_secret = None
    default_audience = None
    if default_config is True:
        default_secret = JWT_FALLBACK_SECRET
        default_audience = os.environ.get(ENV_VARS.HOST, "localhost")
    token_secret = os.environ.get(ENV_VARS.JWT_SECRET, default_secret)
    token_audience = os.environ.get(ENV_VARS.JWT_AUDIENCE, default_audience)
    return token_secret, token_audience


def get_basic_auth_config():
    """Get the HTTP Basic Auth configuration for protecting access to the running prodigy
    static files.

    This is not a full security system, and only offers weak-protection against unwanted
    access. This protection should not be used in production without strong passwords and
    the app served over https to encrypt the user/pass that is entered.

    PRODIGY_BASIC_AUTH_PASS is a string variable containing the password to accept.
    PRODIGY_BASIC_AUTH_USER is a string variable containung the user to accept.

    raises: ValueError if only one of the two environment variables is set
    returns: a tuple of (user, password) which will be (None, None) if basic auth is disabled
    """
    basic_password = os.environ.get(ENV_VARS.BASIC_AUTH_PASS, None)
    basic_username = os.environ.get(ENV_VARS.BASIC_AUTH_USER, None)
    if basic_password is None and basic_username is None:
        return None, None
    if basic_password is None or basic_username is None:
        raise ValueError(
            "Invalid configuration."
            "You cannot specify one HTTP basic auth environment variable without the other"
        )
    return basic_username, basic_password
